# Socket-Programming-Server-in-C-and-Client-in-Python
A simple TCP client-server program, where server in written in C programming language while the client is written in Python programming language.

